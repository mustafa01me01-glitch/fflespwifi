#include <ESP32Servo.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DHT.h>

#define PIR_PIN   27
#define SERVO_PIN 18
#define DHT_PIN   4

const char* WIFI_ADI   = "...";
const char* WIFI_SIFRE = "asafdemir";

WebServer server(80);
Servo arm;
DHT dht(DHT_PIN, DHT11);

int sayac = 0;
unsigned long sonKovma = 0;

void kov() {
  arm.attach(SERVO_PIN);
  for (int tur = 0; tur < 3; tur++) {
    for (int a = 10; a <= 150; a += 2) { arm.write(a); delay(10); }
    for (int a = 150; a >= 10; a -= 2) { arm.write(a); delay(10); }
  }
  arm.detach();
}

void gonder(const char* tip, String icerik) {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, tip, icerik);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  dht.begin();

  WiFi.begin(WIFI_ADI, WIFI_SIFRE);
  while (WiFi.status() != WL_CONNECTED) delay(500);
  Serial.println(WiFi.localIP());

  server.on("/data", []() {
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    if (isnan(h)) h = 0;
    if (isnan(t)) t = 0;
    gonder("application/json",
      "{\"h\":" + String(h, 0) + ",\"t\":" + String(t, 1) + ",\"n\":" + String(sayac) + "}");
  });

  server.on("/test", []() {
    gonder("text/plain", "ok");
    kov();
  });

  server.begin();
}

void loop() {
  server.handleClient();

  if (digitalRead(PIR_PIN) == HIGH && (sonKovma == 0 || millis() - sonKovma > 30000)) {
    sayac++;
    sonKovma = millis();
    kov();
  }
}
